
package com.twitter.challenge.pojos;

import com.squareup.moshi.Json;

public class Weather {

    @Json(name = "temp")
    private Double temp;
    @Json(name = "pressure")
    private Integer pressure;
    @Json(name = "humidity")
    private Integer humidity;

    public Double getTemp() {
        return temp;
    }

    public void setTemp(Double temp) {
        this.temp = temp;
    }

    public Integer getPressure() {
        return pressure;
    }

    public void setPressure(Integer pressure) {
        this.pressure = pressure;
    }

    public Integer getHumidity() {
        return humidity;
    }

    public void setHumidity(Integer humidity) {
        this.humidity = humidity;
    }

}
