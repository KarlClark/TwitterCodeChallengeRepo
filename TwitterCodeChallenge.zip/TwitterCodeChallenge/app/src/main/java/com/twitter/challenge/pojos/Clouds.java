
package com.twitter.challenge.pojos;

import com.squareup.moshi.Json;

public class Clouds {

    @Json(name = "cloudiness")
    private Integer cloudiness;

    public Integer getCloudiness() {
        return cloudiness;
    }

    public void setCloudiness(Integer cloudiness) {
        this.cloudiness = cloudiness;
    }

}
