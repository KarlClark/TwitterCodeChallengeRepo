package com.twitter.challenge.activities_and_fragments;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;

import com.twitter.challenge.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class TodayFragment extends Fragment {

    private NavController navController;

    public TodayFragment() {
        // Required empty public constructor
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        navController = NavHostFragment.findNavController(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_today, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Button btnFiveDay = view.findViewById(R.id.btnFiveDay);
        btnFiveDay.setOnClickListener(v -> Navigation.findNavController(btnFiveDay).navigate(R.id.action_todayFragment_to_fiveDayFragment));
    }
}
