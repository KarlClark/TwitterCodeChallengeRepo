package com.twitter.challenge.activities_and_fragments;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import androidx.navigation.Navigation;

import com.twitter.challenge.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @Override
    public boolean onSupportNavigateUp() {
        // R.id.nav_host_fragment is id of the fragment in the layout file.
        return Navigation.findNavController(this, R.id.nav_host_fragment).navigateUp();
    }
}
